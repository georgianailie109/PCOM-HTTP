#include <stdio.h>      /* printf, sprintf */
#include <stdlib.h>     /* exit, atoi, malloc, free */
#include <unistd.h>     /* read, write, close */
#include <string.h>     /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"
#include "parson.h"
#include <ctype.h>


void register_user(int sockfd, char *message, char *response,
                const char *token) {
    char username[50], password[50], *content_type, *json_string;
    char **body_data = malloc(1 * sizeof(char *));
    int c;
    JSON_Value *val_root;
    JSON_Object *obj_root;

    while ((c = getchar()) != '\n' && c != EOF) {}

    printf("username=");
    if (fgets(username, sizeof(username), stdin)) {
        username[strcspn(username, "\n")] = 0;
    }
    printf("password=");
    if (fgets(password, sizeof(password), stdin)) {
        password[strcspn(password, "\n")] = 0;
    }

    if (strlen(username) == 0) {
        printf("ERROR: Username gol.\n");
        return;
    }
    if (strstr(username, " ") != NULL) {
        printf("ERROR: Username-ul nu poate contine spatii.\n");
        return;
    }
    if (strlen(password) == 0) {
        printf("ERROR: Parola goala.\n");
        return;
    }
    if (strstr(password, " ") != NULL) {
        printf("ERROR: Parola nu poate contine spatii.\n");
        return;
    }

    val_root = json_value_init_object();
    obj_root = json_value_get_object(val_root);

    json_object_set_string(obj_root, "username", username);
    json_object_set_string(obj_root, "password", password);

    json_string = json_serialize_to_string_pretty(val_root);
    body_data[0] = json_string;
    content_type = "application/json";

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_post_request("34.246.184.49", "/api/v1/tema/auth/register",
                                content_type, body_data, 1, NULL, 0, token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);
    if (strstr(response, "error") != NULL) {
        printf("ERROR: Username-ul este deja folosit.\n");
    } else {
        printf("SUCCES: Utilizatorul a fost inregistrat cu succes!\n");
    }

    json_value_free(val_root);
    json_free_serialized_string(json_string);
    close_connection(sockfd);
    free(message);
    free(body_data);
}

void login(int sockfd, char *message, char *response, char **cookies,
            char **token) {
    char username[50], password[50], *content_type, *json_string;
    char *inceput, *final;
    char **body_data = malloc(1 * sizeof(char *));
    int c;
    JSON_Value *val_root, *val_response;
    JSON_Object *obj_root, *obj_response;

    while ((c = getchar()) != '\n' && c != EOF) {}

    printf("username=");
    if (fgets(username, sizeof(username), stdin)) {
        username[strcspn(username, "\n")] = 0;
    }
    printf("password=");
    if (fgets(password, sizeof(password), stdin)) {
        password[strcspn(password, "\n")] = 0;
    }
    val_root = json_value_init_object();
    obj_root = json_value_get_object(val_root);

    json_object_set_string(obj_root, "username", username);
    json_object_set_string(obj_root, "password", password);

    json_string = json_serialize_to_string_pretty(val_root);
    body_data[0] = json_string;
    content_type = "application/json";

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_post_request("34.246.184.49", "/api/v1/tema/auth/login",
                                content_type, body_data, 1, NULL, 0, *token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);

    inceput = strstr(response, "Set-Cookie: ");
    if (inceput != NULL) {
        inceput = inceput + strlen("Set-Cookie: ");
        final = strstr(inceput, ";");
        if (final != NULL) {
            *cookies = calloc(final - inceput + 1, 1);
            strncpy(*cookies, inceput, final - inceput);
        } else if (final == NULL) {
            final = strstr(inceput, "\r\n");
        }
    }

    val_response = json_parse_string(basic_extract_json_response(response));
    if (val_response != NULL) {
        obj_response = json_value_get_object(val_response);
        if (json_object_get_value(obj_response, "token")) {
            const char *aux = json_object_get_string(obj_response, "token");
            if (aux != NULL) {
                free(*token);
                *token = strdup(aux);
            }
        }
        json_value_free(val_response);
    }
    if (*cookies != NULL) {
        printf("SUCCES: Utilizatorul s-a logat cu succes!\n");
    } else {
        printf("ERROR: Logarea a esuat. Credentialele nu corespund!\n");
    }

    json_free_serialized_string(json_string);
    json_value_free(val_root);
    close_connection(sockfd);
    free(body_data);
}

void enter_library(int sockfd, char **token, const char *cookies) {
    char *message, *response;
    char **cookies_copy = malloc(1 * sizeof(char *));
    cookies_copy[0] = strdup(cookies);
    JSON_Value *val_response;
    JSON_Object *obj_response;

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_get_request("34.246.184.49", "/api/v1/tema/library/access",
                                NULL, cookies_copy, 1, *token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);

    if (strstr(response, "error") != NULL) {
        printf("ERROR: Credentialele nu corespund.\n");
    } else {
        printf("SUCCES: Utilizatorul are acces la biblioteca.\n");

        val_response = json_parse_string(basic_extract_json_response(response));
        if (val_response != NULL) {
            obj_response = json_value_get_object(val_response);
            const char *aux = json_object_get_string(obj_response, "token");
            if (aux != NULL) {
                free(*token);
                *token = strdup(aux);
            }
            json_value_free(val_response);
        }
    }

    close_connection(sockfd);
    free(cookies_copy[0]);
    free(cookies_copy);
    free(message);
    free(response);
}

void get_books(int sockfd, char *message, char *response, const char *cookies,
            const char *token) {
    char *books;
    char **cookies_copy = malloc(1 * sizeof(char *));
    cookies_copy[0] = strdup(cookies);

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_get_request("34.246.184.49", "/api/v1/tema/library/books",
                                    NULL, cookies_copy, 1, token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);

    if (strstr(response, "error") != NULL) {
        printf("ERROR: Nu ati demonstrat ca aveti acces in biblioteca.\n");
    } else {
        books = basic_extract_json_response(response);
        if (books) {
            printf("%s\n", books);
        } else {
            printf("ERROR: Nu exista carti deocamdata.\n");
        }
    }

    close_connection(sockfd);
    free(cookies_copy[0]);
    free(cookies_copy);
}

void get_book(int sockfd, char *message, char *response, const char *cookies,
            const char *token) {
    char url[256], *book;
    int id;
    char **cookies_copy = malloc(1 * sizeof(char *));
    cookies_copy[0] = strdup(cookies);

    printf("id=");
    scanf("%d", &id);
    getchar();
    sprintf(url, "/api/v1/tema/library/books/%d", id);

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_get_request("34.246.184.49", url, NULL, cookies_copy,
                                    1, token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);

    if (strstr(response, "error") != NULL) {
        printf("ERROR: Nu ati demonstrat ca aveti acces in biblioteca.\n");
    } else {
        book = basic_extract_json_response(response);
        if (book != NULL) {
            printf("%s\n", book);
        } else {
            printf("ERROR: Aceasta carte nu exista in sistem.\n");
        }
    }

    close_connection(sockfd);
    free(cookies_copy[0]);
    free(cookies_copy);
}

int is_number(const char *str) {
    int i = 0;
    while (str[i] != '\0') {
        if (isdigit(str[i]) == 0) {
            return 0;
        }
        i++;
    }
    return 1;
}

void add_book(int sockfd, char *message, char *response, const char *cookies,
            const char *token) {
    char title[256], author[256], genre[256], publisher[256], nr_page[256];
    char *json_string;
    int page_count, c, k = 0;
    char **cookies_copy = malloc(1 * sizeof(char *));
    cookies_copy[0] = strdup(cookies);
    JSON_Value *val_root;
    JSON_Object *obj_root;

    if (cookies == NULL || strlen(cookies) == 0 || token == NULL ||
        strlen(token) == 0) {
        printf("ERROR: Nu aveti acces in biblioteca.\n");
        return;
    }

    while ((c = getchar()) != '\n' && c != EOF) {}

    printf("title=");
    if (fgets(title, sizeof(title), stdin)) {
        title[strcspn(title, "\n")] = 0;
    }
    printf("author=");
    if (fgets(author, sizeof(author), stdin)) {
        author[strcspn(author, "\n")] = 0;
    }
    printf("genre=");
    if (fgets(genre, sizeof(genre), stdin)) {
        genre[strcspn(genre, "\n")] = 0;
    }
    printf("publisher=");
    if (fgets(publisher, sizeof(publisher), stdin)) {
        publisher[strcspn(publisher, "\n")] = 0;
    }
    printf("page_count=");
    if (fgets(nr_page, sizeof(nr_page), stdin)) {
        nr_page[strcspn(nr_page, "\n")] = 0;
    }

    if (strlen(title) == 0) {
        printf("ERROR: Titlul nu este valid.\n");
        k++;
    }
    if (strlen(author) == 0) {
        printf("ERROR: Autorul nu este valid.\n");
        k++;
    }
    if (strlen(genre) == 0) {
        printf("ERROR: Tipul cartii nu este valid.\n");
        k++;
    }
    if (strlen(publisher) == 0) {
        printf("ERROR: Editura nu este valida.\n");
        k++;
    }
    if (is_number(nr_page) == 0 || sscanf(nr_page, "%d", &page_count) != 1 ||
        page_count < 1) {
        printf("ERROR: Numarul paginilor nu este valid.\n");
        k++;
    }
    
    if (k > 0) {
        return;
    }

    val_root = json_value_init_object();
    obj_root = json_value_get_object(val_root);

    json_object_set_string(obj_root, "title", title);
    json_object_set_string(obj_root, "author", author);
    json_object_set_string(obj_root, "genre", genre);
    json_object_set_string(obj_root, "publisher", publisher);
    json_object_set_number(obj_root, "page_count", page_count);

    json_string = json_serialize_to_string(val_root);

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_post_request("34.246.184.49", "/api/v1/tema/library/books",
                    "application/json", &json_string, 1, cookies_copy, 1, token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);

    if (strstr(response, "error") != NULL) {
        printf("ERROR: Nu ati demonstrat ca aveti acces in biblioteca.\n");
    } else {
        printf("SUCCESS: Cartea a fost adaugata cu succes!\n");
    }

    close_connection(sockfd);
    json_free_serialized_string(json_string);
    json_value_free(val_root);
    free(cookies_copy[0]);
    free(cookies_copy);
}

void delete_book(int sockfd, char *message, char *response, const char *cookies,
            const char *token) {
    char url[256];
    int id;
    char **cookies_copy = malloc(1 * sizeof(char *));
    cookies_copy[0] = strdup(cookies);
    printf("id=");
    scanf("%d", &id);
    getchar();
    
    if (cookies == NULL) {
        printf("ERROR: Te rog sa te autentifici mai intai.\n");
        return;
    }

    sprintf(url, "/api/v1/tema/library/books/%d", id);

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_delete_request("34.246.184.49", url, NULL, cookies_copy,
                                        1, token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);

    if (strstr(response, "error") != NULL) {
        printf("ERROR: Nu ati demonstrat ca aveti acces in biblioteca.\n");
    } else {
        printf("SUCCES: Cartea a fost stearsa cu succes!\n");
    }

    close_connection(sockfd);
    free(cookies_copy[0]);
    free(cookies_copy);
}

void logout(int sockfd, char **cookies, const char *token) {
    char *message, *response;
    if (*cookies == NULL) {
        printf("ERROR: Nu sunteti autentificat.\n");
        return;
    }

    sockfd = open_connection("34.246.184.49", 8080, AF_INET, SOCK_STREAM, 0);
    message = compute_get_request("34.246.184.49", "/api/v1/tema/auth/logout",
                                    NULL, cookies, 1, token);

    send_to_server(sockfd, message);
    response = receive_from_server(sockfd);

    if (strstr(response, "error") != NULL) {
        printf("ERROR: Nu ati demonstrat ca aveti acces in biblioteca.\n");
    } else {
        printf("SUCCES: Utilizatorul a fost delogat cu succes!\n");
        free(*cookies);
        *cookies = NULL;
        token = NULL;
    }

    close_connection(sockfd);
    free(message);
    free(response);
}


int main(int argc, char *argv[])
{
    char *message = NULL;
    char *response = NULL;
    char comanda[50];
    int sockfd = -1;
    char *cookies = NULL;
    char *token = NULL;

    while (1) {
        scanf("%s", comanda);
        if (strcmp(comanda, "register") == 0) {
            register_user(sockfd, message, response, token);
        } else if (strcmp(comanda, "login") == 0) {
            login(sockfd, message, response, &cookies, &token);
        } else if (strcmp(comanda, "enter_library") == 0) {
            if (cookies != NULL) {
                enter_library(sockfd, &token, cookies);
            } else {
                printf("ERROR: Te rog sa te autentifici mai intai.\n");
            }
        } else if (strcmp(comanda, "get_books") == 0) {
            if (cookies != NULL) {
                get_books(sockfd, message, response, cookies, token);
            } else {
                printf("ERROR: Te rog sa te autentifici mai intai.\n");
            }
        } else if (strcmp(comanda, "get_book") == 0) {
            if (cookies != NULL) {
                get_book(sockfd, message, response, cookies, token);
            } else {
                printf("ERROR: Te rog sa te autentifici mai intai.\n");
            }
        } else if (strcmp(comanda, "add_book") == 0) {
            if (cookies != NULL) {
                add_book(sockfd, message, response, cookies, token);
            } else {
                printf("ERROR: Te rog sa te autentifici mai intai.\n");
            }
        } else if (strcmp(comanda, "delete_book") == 0) {
            delete_book(sockfd, message, response, cookies, token);
        } else if (strcmp(comanda, "logout") == 0) {
            logout(sockfd, &cookies, token);
        } else if (strcmp(comanda, "exit") == 0) {
            close_connection(sockfd);
            return 0;
        }
    }

    return 0;
}
